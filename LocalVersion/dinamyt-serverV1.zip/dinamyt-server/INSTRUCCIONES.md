# DINAMYT — Servidor Local de Red
## Guía de instalación y uso para el campeonato

---

## LO QUE NECESITAS
- Una laptop (Windows, Mac o Linux)
- Node.js instalado → https://nodejs.org  (descargar versión LTS)
- Un celular con plan de datos para crear el hotspot WiFi
- 5 dispositivos móviles (jueces + árbitro) + 1 pantalla (TV/proyector)

---

## INSTALACIÓN (solo la primera vez, 5 minutos)

### Paso 1 — Instalar Node.js
Ir a https://nodejs.org y descargar la versión **LTS**.
Instalar normalmente. Reiniciar la laptop si lo pide.

### Paso 2 — Copiar la carpeta
Copiar la carpeta `dinamyt-server` a la laptop.
Debe contener estos 3 archivos:
```
dinamyt-server/
  ├── server.js
  ├── index.html
  └── package.json
```

### Paso 3 — Instalar dependencias (una sola vez)
Abrir una terminal/cmd DENTRO de la carpeta `dinamyt-server` y ejecutar:
```
npm install
```
Esto descarga el paquete `ws` (WebSockets). Solo necesita internet esta vez.

---

## ARRANCAR EL DÍA DEL CAMPEONATO

### Paso 1 — Activar el hotspot en el celular
Activar "Zona WiFi" o "Hotspot" en el celular que tenga datos.
Conectar la laptop a ese hotspot.

### Paso 2 — Arrancar el servidor
Abrir terminal/cmd en la carpeta `dinamyt-server` y ejecutar:
```
node server.js
```

Verás algo así:
```
╔══════════════════════════════════════════╗
║         DINAMYT — SERVIDOR ACTIVO        ║
╠══════════════════════════════════════════╣
║  Local:   http://localhost:3000           ║
║  Red:     http://192.168.1.105:3000      ║  ← Esta es la URL que importa
╚══════════════════════════════════════════╝
```

### Paso 3 — Conectar todos los dispositivos
1. Conectar TODOS los celulares (jueces, árbitro, pantalla) al mismo hotspot
2. Abrir el navegador en cada celular
3. Escribir la dirección IP que aparece en pantalla, ejemplo:
   `http://192.168.1.105:3000`
4. Seleccionar el rol correspondiente en cada dispositivo

### Paso 4 — Pantalla de proyección
Conectar la laptop a la TV/proyector con HDMI.
Abrir otra pestaña en la laptop con la misma URL y seleccionar "Pantalla".
O conectar un celular a la TV y abrir la URL desde ese celular.

---

## ARQUITECTURA DE RED

```
📱 Juez Esquina 1  ──┐
📱 Juez Esquina 2  ──┤
📱 Juez Esquina 3  ──┤──── Hotspot WiFi ────  💻 Laptop
📱 Juez Esquina 4  ──┤                         (server.js)
📱 Árbitro Central ──┤                              │
📺 Pantalla TV     ──┘                         index.html
                                               WebSocket
```

---

## SOLUCIÓN DE PROBLEMAS

**"No puedo conectarme desde el celular"**
- Verificar que el celular y la laptop estén en el mismo hotspot
- Desactivar el firewall de Windows temporalmente:
  Panel de control → Windows Defender Firewall → Desactivar (solo para redes privadas)
- En Mac: Preferencias del Sistema → Seguridad → Firewall → Permitir conexiones entrantes a Node.js

**"La IP cambió"**
- La IP puede cambiar si apagas el hotspot y lo vuelves a encender
- Simplemente leer la nueva IP en la consola al arrancar `node server.js`

**"Un celular se desconectó"**
- El sistema reconecta automáticamente cada 2 segundos
- El punto verde en el header se pone rojo cuando no hay conexión
- Al reconectar, el servidor envía el estado completo automáticamente

**"Quiero usar 2 tatamis"**
- Arrancar dos instancias del servidor en puertos diferentes:
  ```
  # Terminal 1 - Tatami 1
  node server.js
  
  # Terminal 2 - Tatami 2
  PORT=3001 node server.js    (Mac/Linux)
  set PORT=3001 && node server.js   (Windows)
  ```
- Tatami 1 → http://192.168.x.x:3000
- Tatami 2 → http://192.168.x.x:3001

---

## CONSUMO DE DATOS
El sistema usa WebSockets con mensajes JSON pequeños (~300 bytes por evento).
Para 2 días de uso continuo (12h/día), 2 tatamis, 6 dispositivos c/u:
**Consumo estimado: menos de 50 MB totales.**
Un plan de 1 GB es más que suficiente para todo el campeonato.

---

## PARA PARAR EL SERVIDOR
En la terminal donde corre Node.js, presionar `Ctrl + C`.
