/**
 * DINAMYT — Servidor Multi-Tatami
 * =================================
 * Una sola laptop corre hasta 6 tatamis aislados en paralelo.
 * Cada tatami tiene su propio puerto y estado completamente independiente.
 *
 * INSTALACIÓN (una sola vez, necesitas internet):
 *   npm install ws
 *
 * ARRANQUE:
 *   node server.js
 *
 * URLs resultantes (reemplaza la IP por la de tu laptop):
 *   Tatami 1 → http://192.168.x.x:3001
 *   Tatami 2 → http://192.168.x.x:3002
 *   ...hasta Tatami 6 → http://192.168.x.x:3006
 *
 * Para pantallas HDMI conectadas a la laptop, abrir en esta misma máquina:
 *   Tatami 1 → http://localhost:3001  (presionar F11 para pantalla completa)
 *   Tatami 2 → http://localhost:3002
 *   etc. Puedes abrir cada uno en una pestaña separada del navegador.
 */

const http = require('http');
const fs   = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');
const os   = require('os');

// ══════════════════════════════════════════
//  CONFIGURACIÓN — solo cambia esto
// ══════════════════════════════════════════
const TATAMIS_ACTIVOS = 6;    // cuántos tatamis quieres (1 a 6)
const PUERTO_BASE     = 3001; // Tatami 1=3001, Tatami 2=3002, etc.
// ══════════════════════════════════════════

function estadoInicial() {
  return {
    nombreHong: 'Hong', nombreChung: 'Chung',
    jueces: {
      j1:{hong:0,chung:0}, j2:{hong:0,chung:0},
      j3:{hong:0,chung:0}, j4:{hong:0,chung:0},
    },
    arbHong:0, arbChung:0, historial:[],
    kyongHong:0, kyongChung:0,
    faltasHong:0, faltasChung:0,
    segundos:120, segundosMax:120, activo:false,
    log:[], alerta12Lanzada:false, ronda:'r1',
  };
}

function getLocalIP() {
  for (const ifaces of Object.values(os.networkInterfaces())) {
    for (const i of ifaces) {
      if (i.family === 'IPv4' && !i.internal) return i.address;
    }
  }
  return 'localhost';
}

// Leer index.html una sola vez
const htmlPath = path.join(__dirname, 'index.html');
let htmlBase;
try {
  htmlBase = fs.readFileSync(htmlPath, 'utf-8');
} catch(e) {
  console.error('\nERROR: No encontré index.html en la misma carpeta que server.js\n');
  process.exit(1);
}

// Crear un servidor completamente aislado por tatami
function crearTatami(num, puerto) {
  let estado = estadoInicial();
  const clientes = new Set();

  // Inyectar número de tatami para mostrarlo en la interfaz
  const html = htmlBase.replace(
    '<!-- TATAMI_NUMERO -->',
    `<script>window.TATAMI_NUM = ${num};</script>`
  );

  const server = http.createServer((req, res) => {
    if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
      res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
      res.end(html);
    } else {
      res.writeHead(404); res.end('404');
    }
  });

  const wss = new WebSocketServer({ server });

  wss.on('connection', ws => {
    clientes.add(ws);
    ws.send(JSON.stringify({tipo:'estado', datos:estado}));

    ws.on('message', raw => {
      let m; try { m = JSON.parse(raw); } catch { return; }
      if (m.tipo === 'estado') {
        estado = m.datos;
        broadcast(JSON.stringify({tipo:'estado', datos:estado}), ws);
      }
      if (m.tipo === 'alerta12' || m.tipo === 'derrota' || m.tipo === 'falta-flash' || m.tipo === 'ganador-flash') {
        broadcast(JSON.stringify(m), ws);
      }
      if (m.tipo === 'pedir') {
        ws.send(JSON.stringify({tipo:'estado', datos:estado}));
      }
    });

    ws.on('close', () => clientes.delete(ws));
    ws.on('error', () => clientes.delete(ws));
  });

  function broadcast(msg, origen) {
    for (const c of clientes) {
      if (c !== origen && c.readyState === 1) c.send(msg);
    }
  }

  server.listen(puerto, '0.0.0.0', () =>
    console.log(`  ✓ Tatami ${num}  →  puerto ${puerto}`)
  );
}

// Arrancar todos
console.log('\n╔══════════════════════════════════════════════╗');
console.log('║     DINAMYT — SERVIDOR MULTI-TATAMI          ║');
console.log('╠══════════════════════════════════════════════╣');
for (let i = 1; i <= TATAMIS_ACTIVOS; i++) {
  crearTatami(i, PUERTO_BASE + i - 1);
}

setTimeout(() => {
  const ip = getLocalIP();
  const pad = s => s.padEnd(30);
  console.log('╠══════════════════════════════════════════════╣');
  console.log(`║  IP de la laptop: ${ip.padEnd(27)}║`);
  console.log('╠══════════════════════════════════════════════╣');
  console.log('║  URLs para móviles / jueces / árbitros:      ║');
  for (let i = 1; i <= TATAMIS_ACTIVOS; i++) {
    console.log(`║   Tatami ${i}  http://${pad(ip+':'+(PUERTO_BASE+i-1))}║`);
  }
  console.log('╠══════════════════════════════════════════════╣');
  console.log('║  URLs para pantallas HDMI en esta laptop:    ║');
  for (let i = 1; i <= TATAMIS_ACTIVOS; i++) {
    console.log(`║   Tatami ${i}  http://${pad('localhost:'+(PUERTO_BASE+i-1))}║`);
  }
  console.log('╠══════════════════════════════════════════════╣');
  console.log('║  Ctrl+C para detener todo                    ║');
  console.log('╚══════════════════════════════════════════════╝\n');
}, 500);
