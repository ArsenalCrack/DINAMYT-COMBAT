# DINAMYT — Servidor Multi-Tatami v3
## Guía de instalación y uso para el campeonato

---

## LO QUE NECESITAS
- Una laptop (Windows, Mac o Linux)
- Node.js instalado → https://nodejs.org  (descargar versión LTS)
- Un celular con plan de datos para crear el hotspot WiFi
- Por tatami: 4 réferis de esquina + 1 réferi central + 1 pantalla de proyección
- Total dispositivos: hasta 6 por tatami × 6 tatamis = 36 dispositivos simultáneos

---

## INSTALACIÓN (solo la primera vez, 5 minutos)

### Paso 1 — Instalar Node.js
Ir a https://nodejs.org y descargar la versión **LTS**.
Instalar normalmente. Reiniciar la laptop si lo pide.

### Paso 2 — Copiar la carpeta
Copiar la carpeta `dinamyt-server` a la laptop.
Debe contener estos archivos:
```
dinamyt-server/
  ├── server.js       ← Servidor multi-tatami v3 (eventos delta)
  ├── index.html      ← Interfaz HTML compartida
  ├── app.js          ← Lógica del cliente (estado, renders, eventos)
  ├── app.css         ← Estilos de la interfaz
  └── package.json    ← Dependencias (ws)
```

### Paso 3 — Instalar dependencias (una sola vez)
Abrir una terminal/cmd DENTRO de la carpeta `dinamyt-server` y ejecutar:
```
npm install
```
Esto descarga el paquete `ws` (WebSockets). Solo necesita internet esta vez.

---

## ARRANCAR EL DÍA DEL CAMPEONATO

### Paso 1 — Activar el hotspot en el celular
Activar "Zona WiFi" o "Hotspot" en el celular que tenga datos.
Conectar la laptop a ese hotspot.

### Paso 2 — Arrancar el servidor
Abrir terminal/cmd en la carpeta `dinamyt-server` y ejecutar:
```
node server.js
```
Se pedirá una contraseña de acceso. Al ingresarla correctamente, verás:

```
╔══════════════════════════════════════════════╗
║     DINAMYT — SERVIDOR MULTI-TATAMI v3       ║
╠══════════════════════════════════════════════╣
║  ✓ Tatami 1  →  puerto 3001                 ║
║  ✓ Tatami 2  →  puerto 3002                 ║
║  ✓ Tatami 3  →  puerto 3003                 ║
║  ✓ Tatami 4  →  puerto 3004                 ║
║  ✓ Tatami 5  →  puerto 3005                 ║
║  ✓ Tatami 6  →  puerto 3006                 ║
╠══════════════════════════════════════════════╣
║  IP de la laptop: 192.168.x.x               ║
╠══════════════════════════════════════════════╣
║  URLs para móviles / réferis:                ║
║   Tatami 1  http://192.168.x.x:3001         ║
║   Tatami 2  http://192.168.x.x:3002         ║
║   ...                                        ║
╠══════════════════════════════════════════════╣
║  URLs HDMI (esta laptop):                    ║
║   Tatami 1  http://localhost:3001            ║
║   Tatami 2  http://localhost:3002            ║
║   ...                                        ║
╠══════════════════════════════════════════════╣
║  Arquitectura v3: eventos delta + ACK        ║
║  Ctrl+C para detener                         ║
╚══════════════════════════════════════════════╝
```

### Paso 3 — Conectar todos los dispositivos
1. Conectar TODOS los celulares (réferis, pantalla) al mismo hotspot
2. Abrir el navegador en cada celular
3. Escribir la dirección IP + puerto del tatami, ejemplo:
   - Tatami 1: `http://192.168.x.x:3001`
   - Tatami 2: `http://192.168.x.x:3002`
4. Seleccionar el rol correspondiente en cada dispositivo:
   - **Réferi Esquina 1-2**: Asignados a Hong (rojo)
   - **Réferi Esquina 3-4**: Asignados a Chung (azul)
   - **Réferi Central**: Cronómetro, puntos especiales, faltas, control general
   - **Pantalla de Proyección**: Marcador público para espectadores

### Paso 4 — Pantalla de proyección
Conectar la laptop a la TV/proyector con HDMI.
Abrir otra pestaña en la laptop con `http://localhost:300X` (X = número de tatami).
Seleccionar "Pantalla de Proyección". Se activará pantalla completa automáticamente.

---

## CONFIGURACIÓN DEL SERVIDOR

El archivo `server.js` tiene estas constantes configurables al inicio:
```javascript
const TATAMIS_ACTIVOS = 6;        // Número de tatamis (1 a N)
const PUERTO_BASE     = 3001;     // Puerto del primer tatami
const CLAVE_ACCESO    = 'Amy2026*'; // Contraseña de arranque
```

---

## ARQUITECTURA v3: EVENTOS DELTA + ACK

### ¿Cómo funciona?
El sistema usa **eventos delta** en lugar de enviar el estado completo:

1. **Un réferi toca un botón** → se genera un evento delta (ej: `punto_juez +1 hong`)
2. **Se aplica localmente** de inmediato (optimistic update) para respuesta instantánea
3. **Se envía al servidor** con un ID único
4. **El servidor aplica el evento** atómicamente al estado central (fuente de verdad)
5. **El servidor envía ACK** al emisor y difunde el estado actualizado a todos
6. **Si no llega ACK**, el cliente reintenta automáticamente (hasta 8 veces)

### ¿Por qué es mejor?
- **Sin race conditions**: El servidor procesa eventos uno por uno
- **Sin pérdida de puntos**: Reintentos automáticos con deduplicación
- **Respuesta instantánea**: UI se actualiza antes de esperar al servidor
- **Reconexión inteligente**: Al reconectar, solicita estado completo

### Tipos de eventos delta
| Evento | Origen | Descripción |
|--------|--------|-------------|
| `punto_juez` | Réferi esquina | Sumar puntos: +1 cuerpo, +2 giro/cabeza, +3 giro cabeza |
| `deshacer_juez` | Réferi esquina | Deshacer último punto del réferi |
| `especial` | Réferi central | Puntos especiales: Knock Down, Derribo, Proyecciones |
| `deshacer_arbitro` | Réferi central | Deshacer última acción del réferi central por color |
| `kyonggo` | Réferi central | Advertencia (cada 3 → GamJeum automático, 6 → DQ) |
| `gamjeum` | Réferi central | Deducción directa de -1 punto |
| `crono_start/pause/reset` | Réferi central | Control del cronómetro (el servidor lleva el tiempo) |
| `ronda` | Réferi central | Cambiar ronda: R1, R2, Punto de Oro |
| `nombres` | Réferi central | Actualizar nombres de competidores |
| `reset` | Réferi central | Nuevo combate / reiniciar marcador |

---

## ARQUITECTURA DE RED

```
📱 Réferi Esquina 1  ──┐
📱 Réferi Esquina 2  ──┤
📱 Réferi Esquina 3  ──┤──── Hotspot WiFi ────  💻 Laptop (server.js)
📱 Réferi Esquina 4  ──┤                        ├── Tatami 1 (puerto 3001)
⚖️ Réferi Central    ──┤                        ├── Tatami 2 (puerto 3002)
📺 Pantalla TV       ──┘                        ├── ...
                                                 └── Tatami 6 (puerto 3006)
```

Cada tatami tiene su propio servidor WebSocket independiente.
Los dispositivos se conectan al puerto del tatami correspondiente.

---

## ROLES Y FUNCIONALIDADES

### Réferi de Esquina (j1, j2, j3, j4)
- Botones grandes para marcar puntos: +1, +2, +3
- j1 y j2 están asignados a Hong (rojo)
- j3 y j4 están asignados a Chung (azul)
- Cada réferi solo ve y deshace SUS propios puntos
- Los puntos de los 4 réferis se **suman** para el marcador

### Réferi Central (árbitro)
- **Cronómetro**: SheCak (iniciar) / GallYoe (pausar) / KuMan (fin)
- **Puntos especiales**: Knock Down (+2), Derribo/Barrida (+2)
- **Proyecciones**: 1 pie en suelo (+1), 2 pies en aire (+2)
- **KyongGo**: Advertencias (cada 3 → -1 punto automático, 6 → DQ)
- **GamJeum**: Deducción directa (-1 punto)
- **Deshacer**: Revierte la última acción del réferi central por competidor
- **Descalificación**: DQ manual con confirmación
- **Declarar ganador**: SUNG — seleccionar ganador
- **Rondas**: R1, R2, Punto de Oro
- **Control**: Nuevo combate, Reset marcador

### Pantalla de Proyección
- Marcador compuesto grande (suma esquinas + árbitro)
- Nombres de competidores
- Cronómetro con estados visuales (activo/pausado/urgente)
- Badges de advertencias y faltas
- Log de últimas 6 acciones
- Flash de faltas/advertencias/puntos especiales
- Overlay de ganador (SUNG)
- Se activa en pantalla completa automáticamente

---

## FÓRMULA DEL MARCADOR

```
Marcador Final = SUMA(puntos réferis esquina) + puntos réferi central
```

- **Puntos réferis esquina**: Se suman TODOS (no se promedian)
- **Puntos réferi central**: Knock Down, Derribo, Proyecciones, menos GamJeum

---

## SOLUCIÓN DE PROBLEMAS

**"No puedo conectarme desde el celular"**
- Verificar que el celular y la laptop estén en el mismo hotspot
- Desactivar el firewall de Windows temporalmente:
  Panel de control → Windows Defender Firewall → Desactivar (solo para redes privadas)
- En Mac: Preferencias del Sistema → Seguridad → Firewall → Permitir conexiones entrantes a Node.js

**"La IP cambió"**
- La IP puede cambiar si apagas el hotspot y lo vuelves a encender
- Simplemente leer la nueva IP en la consola al arrancar `node server.js`

**"Un celular se desconectó"**
- El sistema reconecta automáticamente cada 2 segundos
- El punto verde en el header se pone rojo cuando no hay conexión
- Al reconectar, el servidor envía el estado completo automáticamente

**"Los puntos no se marcan / no aparecen en pantalla"**
- Verificar que el indicador de conexión esté verde ("EN VIVO")
- Si dice "ENVIANDO (N)", hay eventos pendientes — revisar conexión WiFi
- Si un réferi de esquina presiona un botón y aparece el mensaje flash pero el puntaje no cambia, verificar que no haya errores en la consola del navegador (F12 → Console)
- Probar con "↩ DESHACER" y volver a marcar

**"La sesión se perdió al recargar"**
- El sistema guarda la sesión automáticamente en localStorage
- Al recargar aparece un banner de recuperación — seleccionar "RECUPERAR"
- Si se ignora, la sesión se pierde pero los puntos siguen en el servidor

**"El cronómetro no está sincronizado"**
- El servidor es la única fuente de verdad del cronómetro
- Cada segundo, el servidor envía el tiempo actualizado a todos
- Si la hora local se ve desincronizada, es un problema de red momentáneo

---

## CONSUMO DE DATOS
El sistema usa WebSockets con mensajes JSON pequeños (~300 bytes por evento).
Para 2 días de uso continuo (12h/día), 6 tatamis, 6 dispositivos c/u:
**Consumo estimado: menos de 100 MB totales.**
Un plan de 1 GB es más que suficiente para todo el campeonato.

---

## PARA PARAR EL SERVIDOR
En la terminal donde corre Node.js, presionar `Ctrl + C`.
