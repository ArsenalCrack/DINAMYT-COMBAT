/**
 * DINAMYT — Servidor Multi-Tatami v3 (arquitectura de eventos delta)
 * ===================================================================
 * INSTALACIÓN (una sola vez): npm install ws
 * ARRANQUE: node server.js
 *
 * CAMBIO CLAVE v3: El servidor ya NO acepta estado completo de los clientes.
 * Solo acepta EVENTOS DELTA (ej: "sumar +1 a hong del juez j1").
 * El servidor es la única fuente de verdad y aplica cada evento atómicamente.
 * Esto elimina race conditions y pérdida de puntos por red congestionada.
 */

const http     = require('http');
const fs       = require('fs');
const path     = require('path');
const { WebSocketServer } = require('ws');
const os       = require('os');
const readline = require('readline');

// ══════════════════════════════════════════
//  CONFIGURACIÓN
// ══════════════════════════════════════════
const TATAMIS_ACTIVOS = 6;
const PUERTO_BASE     = 3001;
const CLAVE_ACCESO    = 'Amy2026*';
// Cuántos IDs de eventos recordar para deduplicación
const MAX_EVENTOS_VISTOS = 500;
// ══════════════════════════════════════════

function estadoInicial() {
  return {
    nombreHong:'Hong', nombreChung:'Chung',
    jueces:{
      j1:{hong:0,chung:0}, j2:{hong:0,chung:0},
      j3:{hong:0,chung:0}, j4:{hong:0,chung:0}
    },
    arbHong:0, arbChung:0,
    historial:[],
    kyongHong:0, kyongChung:0,
    faltasHong:0, faltasChung:0,
    segundos:120, segundosMax:120, activo:false,
    log:[], alerta12Lanzada:false, ronda:'r1',
  };
}

function getLocalIP() {
  for (const ifaces of Object.values(os.networkInterfaces()))
    for (const i of ifaces)
      if (i.family === 'IPv4' && !i.internal) return i.address;
  return 'localhost';
}

// ══════════════════════════════════════════
//  LEER CLAVE EN CONSOLA
// ══════════════════════════════════════════
function pedirClave() {
  return new Promise((resolve) => {
    console.log('\n╔══════════════════════════════════════════════╗');
    console.log('║          DINAMYT — ACCESO AL SERVIDOR        ║');
    console.log('╠══════════════════════════════════════════════╣');
    console.log('║  Ingresa la contraseña para iniciar.         ║');
    console.log('╚══════════════════════════════════════════════╝\n');
    process.stdout.write('  Contraseña: ');

    let clave = '';
    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.setEncoding('utf8');

    const onData = (char) => {
      if (char === '\r' || char === '\n') {
        process.stdin.removeListener('data', onData);
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.stdin.pause();
        process.stdout.write('\n');
        resolve(clave);
        return;
      }
      if (char === '\u0003') { console.log('\n\n  Cancelado.\n'); process.exit(0); }
      if (char === '\u007f' || char === '\b') {
        if (clave.length > 0) { clave = clave.slice(0,-1); process.stdout.write('\b \b'); }
        return;
      }
      clave += char;
      process.stdout.write('*');
    };
    process.stdin.on('data', onData);
  });
}

async function iniciar() {
  const MAX = 3;
  for (let i = 1; i <= MAX; i++) {
    const clave = await pedirClave();
    if (clave === CLAVE_ACCESO) {
      console.log('\n  ✓ Clave correcta. Iniciando DINAMYT...\n');
      arrancarServidor();
      return;
    }
    const r = MAX - i;
    if (r > 0) console.log(`\n  ✗ Incorrecta. ${r} intento${r>1?'s':''} restante${r>1?'s':''}.\n`);
    else { console.log('\n  ✗ Demasiados intentos. Cerrando.\n'); process.exit(1); }
  }
}

// ══════════════════════════════════════════
//  APLICAR EVENTO DELTA AL ESTADO (servidor)
//  Esta función es el corazón del sistema anti-race-condition.
//  Solo el servidor modifica el estado, y lo hace de forma atómica.
// ══════════════════════════════════════════
function aplicarEvento(estado, ev) {
  switch (ev.accion) {

    case 'punto_juez':
      // ev: { juez, color, pts, nombre }
      if (!estado.jueces[ev.juez]) break;
      estado.jueces[ev.juez][ev.color] += ev.pts;
      estado.historial.push({ juez: ev.juez, color: ev.color, pts: ev.pts, nombre: ev.nombre });
      _agregarLog(estado, `${ev.color==='hong'?'🔴':'🔵'} ${ev.nombre} +${ev.pts}`, ev.color);
      break;

    case 'deshacer_juez':
      // ev: { juez }
      const ixJ = [...estado.historial].reverse().findIndex(h => h.juez === ev.juez);
      if (ixJ !== -1) {
        const ri = estado.historial.length - 1 - ixJ;
        const h  = estado.historial[ri];
        estado.jueces[h.juez][h.color] -= h.pts;
        estado.historial.splice(ri, 1);
        _agregarLog(estado, `↩ Deshacer ${ev.juez}`, 'arb');
      }
      break;

    case 'especial':
      // ev: { color, pts, nombre }
      if (ev.color === 'hong') estado.arbHong += ev.pts;
      else estado.arbChung += ev.pts;
      estado.historial.push({ juez:'arbitro', color:ev.color, pts:ev.pts, nombre:ev.nombre, esEspecial:true });
      _agregarLog(estado, `${ev.color==='hong'?'🔴':'🔵'} ⭐ ${ev.nombre} +${ev.pts}`, ev.color);
      break;

    case 'deshacer_arbitro':
      // ev: { color }
      const ixA = [...estado.historial].reverse().findIndex(
        h => h.juez === 'arbitro' && h.color === ev.color
      );
      if (ixA !== -1) {
        const ri = estado.historial.length - 1 - ixA;
        const h  = estado.historial[ri];
        if (h.esKyongGo) {
          if (ev.color === 'hong') { estado.kyongHong = Math.max(0, estado.kyongHong-1); if (estado.kyongHong===1) estado.arbChung=Math.max(0,estado.arbChung-1); }
          else { estado.kyongChung = Math.max(0, estado.kyongChung-1); if (estado.kyongChung===1) estado.arbHong=Math.max(0,estado.arbHong-1); }
        } else if (h.esGamJeum) {
          if (ev.color === 'hong') { estado.arbHong += 1; estado.faltasHong = Math.max(0, estado.faltasHong-1); }
          else { estado.arbChung += 1; estado.faltasChung = Math.max(0, estado.faltasChung-1); }
        } else {
          if (ev.color === 'hong') estado.arbHong -= h.pts;
          else estado.arbChung -= h.pts;
        }
        estado.historial.splice(ri, 1);
        _agregarLog(estado, `↩ Deshacer árbitro: ${ev.color}`, 'arb');
      }
      break;

    case 'kyonggo':
      // ev: { color }
      if (ev.color === 'hong') {
        estado.kyongHong++;
        estado.historial.push({ juez:'arbitro', color:'hong', nombre:`KyongGo #${estado.kyongHong}`, pts:0, esKyongGo:true });
        _agregarLog(estado, `🔴 KyongGo #${estado.kyongHong} — Hong`, 'hong');
        // Cada 3 advertencias → GamJeum automático
        if (estado.kyongHong % 3 === 0 && estado.kyongHong < 6) {
          estado.arbHong -= 1;
          estado.faltasHong++;
          estado.historial.push({ juez:'arbitro', color:'hong', nombre:`GamJeum auto #${estado.faltasHong} (3ª KyongGo)`, pts:-1, esGamJeum:true });
          _agregarLog(estado, `🔴 GamJeum automático −1 (3ª advertencia)`, 'hong');
        }
        // (2ª advertencia ya no otorga +1 al rival)
      } else {
        estado.kyongChung++;
        estado.historial.push({ juez:'arbitro', color:'chung', nombre:`KyongGo #${estado.kyongChung}`, pts:0, esKyongGo:true });
        _agregarLog(estado, `🔵 KyongGo #${estado.kyongChung} — Chung`, 'chung');
        if (estado.kyongChung % 3 === 0 && estado.kyongChung < 6) {
          estado.arbChung -= 1;
          estado.faltasChung++;
          estado.historial.push({ juez:'arbitro', color:'chung', nombre:`GamJeum auto #${estado.faltasChung} (3ª KyongGo)`, pts:-1, esGamJeum:true });
          _agregarLog(estado, `🔵 GamJeum automático −1 (3ª advertencia)`, 'chung');
        }
        // (2ª advertencia ya no otorga +1 al rival)
      }
      break;

    case 'gamjeum':
      // ev: { color }
      if (ev.color === 'hong') { estado.arbHong -= 1; estado.faltasHong++; estado.historial.push({ juez:'arbitro', color:'hong', nombre:`GamJeum #${estado.faltasHong}`, pts:-1, esGamJeum:true }); }
      else { estado.arbChung -= 1; estado.faltasChung++; estado.historial.push({ juez:'arbitro', color:'chung', nombre:`GamJeum #${estado.faltasChung}`, pts:-1, esGamJeum:true }); }
      _agregarLog(estado, `${ev.color==='hong'?'🔴':'🔵'} GamJeum −1`, ev.color);
      break;

    case 'nombres':
      estado.nombreHong = ev.nombreHong || 'Hong';
      estado.nombreChung = ev.nombreChung || 'Chung';
      break;

    case 'crono_tick':
      // Solo el servidor maneja el tick del cronómetro
      // (el cliente solo envía start/pause/reset)
      break;

    case 'crono_start':
      estado.activo = true;
      break;

    case 'crono_pause':
      estado.activo = false;
      break;

    case 'crono_reset':
      estado.activo = false;
      estado.segundos = ev.segundosMax || estado.segundosMax;
      if (ev.segundosMax) estado.segundosMax = ev.segundosMax;
      break;

    case 'crono_seg':
      // Actualización de segundos desde el réferi central
      estado.segundos = ev.segundos;
      estado.activo   = ev.activo;
      break;

    case 'ronda':
      estado.ronda = ev.ronda;
      _agregarLog(estado, `🔢 Ronda: ${ev.ronda}`, 'arb');
      break;

    case 'reset':
      const max = estado.segundosMax;
      Object.assign(estado, estadoInicial());
      estado.segundosMax = max;
      estado.segundos    = max;
      _agregarLog(estado, '↺ Reset', 'arb');
      break;
  }

  // Limitar historial a 200 entradas
  if (estado.historial.length > 200) estado.historial = estado.historial.slice(-200);
  return estado;
}

function _agregarLog(estado, txt, color) {
  estado.log.unshift({ txt, color, ts: Date.now() });
  if (estado.log.length > 15) estado.log = estado.log.slice(0, 15);
}

// ══════════════════════════════════════════
//  SERVIDOR
// ══════════════════════════════════════════
function arrancarServidor() {
  const htmlPath = path.join(__dirname, 'index.html');
  let htmlBase;
  try { htmlBase = fs.readFileSync(htmlPath, 'utf-8'); }
  catch(e) { console.error('ERROR: No encontré index.html.\n'); process.exit(1); }

  function crearTatami(num, puerto) {
    let estado    = estadoInicial();
    const clientes = new Set();
    // Set de IDs de eventos ya procesados (anti-duplicado)
    const eventosVistos = new Set();
    let secuencia = 0; // para ordenar eventos concurrentes

    // Cronómetro interno del servidor (autoritativo)
    let cronIntervalo = null;

    function iniciarCronServidor() {
      if (cronIntervalo) return;
      cronIntervalo = setInterval(() => {
        if (!estado.activo || estado.segundos <= 0) {
          if (estado.segundos <= 0) {
            estado.activo = false;
            _agregarLog(estado, '⏱ KuMan — Fin del tiempo', 'arb');
            clearInterval(cronIntervalo);
            cronIntervalo = null;
          }
          return;
        }
        estado.segundos--;
        broadcastEstado();
      }, 1000);
    }

    function detenerCronServidor() {
      if (cronIntervalo) { clearInterval(cronIntervalo); cronIntervalo = null; }
    }

    const html = htmlBase.replace(
      '<!-- TATAMI_NUMERO -->',
      `<script>window.TATAMI_NUM = ${num};</script>`
    );

    // Cargar archivos estáticos una sola vez por tatami
    const cssPath = path.join(__dirname, 'app.css');
    const jsPath  = path.join(__dirname, 'app.js');
    const cssContent = fs.existsSync(cssPath) ? fs.readFileSync(cssPath,'utf-8') : '';
    const jsContent  = fs.existsSync(jsPath)  ? fs.readFileSync(jsPath,'utf-8')  : '';

    const server = http.createServer((req, res) => {
      const url = req.url.split('?')[0]; // ignorar query strings
      if (req.method === 'GET' && (url === '/' || url === '/index.html')) {
        res.writeHead(200, {'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache'});
        res.end(html);
      } else if (req.method === 'GET' && url === '/app.css') {
        res.writeHead(200, {'Content-Type':'text/css; charset=utf-8','Cache-Control':'no-cache'});
        res.end(cssContent);
      } else if (req.method === 'GET' && url === '/app.js') {
        res.writeHead(200, {'Content-Type':'application/javascript; charset=utf-8','Cache-Control':'no-cache'});
        res.end(jsContent);
      } else {
        res.writeHead(404); res.end('404');
      }
    });

    const wss = new WebSocketServer({ server });

    wss.on('connection', ws => {
      clientes.add(ws);
      // Enviar estado completo al nuevo cliente
      ws.send(JSON.stringify({ tipo:'estado', datos: clonar(estado) }));

      ws.on('message', raw => {
        let m;
        try { m = JSON.parse(raw); } catch { return; }

        // ── Solicitud de estado completo (reconexión) ──
        if (m.tipo === 'pedir') {
          ws.send(JSON.stringify({ tipo:'estado', datos: clonar(estado) }));
          return;
        }

        // ── Eventos de broadcast puro (no modifican estado) ──
        if (['alerta12','derrota','falta-flash','ganador-flash'].includes(m.tipo)) {
          broadcastTodos(JSON.stringify(m));
          return;
        }

        // ── Evento delta — el núcleo del nuevo sistema ──
        if (m.tipo === 'evento') {
          const ev     = m.evento;
          const evId   = m.evId; // ID único generado por el cliente

          // Deduplicación: ignorar si ya procesamos este evento
          if (evId && eventosVistos.has(evId)) {
            // Reenviar ACK aunque ya lo procesamos (cliente puede estar esperando)
            ws.send(JSON.stringify({ tipo:'ack', evId }));
            return;
          }
          if (evId) {
            eventosVistos.add(evId);
            // Limitar memoria del set
            if (eventosVistos.size > MAX_EVENTOS_VISTOS) {
              const first = eventosVistos.values().next().value;
              eventosVistos.delete(first);
            }
          }

          // Aplicar evento al estado del servidor (fuente de verdad)
          aplicarEvento(estado, ev);

          // Manejar cronómetro del servidor
          if (ev.accion === 'crono_start') iniciarCronServidor();
          if (ev.accion === 'crono_pause' || ev.accion === 'crono_reset' || ev.accion === 'reset') detenerCronServidor();

          // Confirmar al emisor
          if (evId) ws.send(JSON.stringify({ tipo:'ack', evId }));

          // Difundir estado actualizado a todos los demás
          broadcastEstado(ws);
          return;
        }

        // ── Compatibilidad: estado completo legacy (solo árbitro en modo standalone) ──
        if (m.tipo === 'estado') {
          // Aceptar pero con menor prioridad — solo si no hay eventos delta activos
          estado = m.datos;
          broadcast(JSON.stringify({ tipo:'estado', datos: clonar(estado) }), ws);
        }
      });

      ws.on('close', () => clientes.delete(ws));
      ws.on('error', () => clientes.delete(ws));
    });

    function broadcastEstado(origen) {
      const msg = JSON.stringify({ tipo:'estado', datos: clonar(estado) });
      for (const c of clientes)
        if (c !== origen && c.readyState === 1) c.send(msg);
      // También enviar al origen para confirmar el estado aplicado
      if (origen && origen.readyState === 1)
        origen.send(JSON.stringify({ tipo:'estado_confirmado', datos: clonar(estado) }));
    }

    function broadcast(msg, origen) {
      for (const c of clientes)
        if (c !== origen && c.readyState === 1) c.send(msg);
    }

    function broadcastTodos(msg) {
      for (const c of clientes)
        if (c.readyState === 1) c.send(msg);
    }

    function clonar(obj) {
      return JSON.parse(JSON.stringify(obj));
    }

    server.listen(puerto, '0.0.0.0', () =>
      console.log(`  ✓ Tatami ${num}  →  puerto ${puerto}`)
    );
  }

  console.log('╔══════════════════════════════════════════════╗');
  console.log('║     DINAMYT — SERVIDOR MULTI-TATAMI v3       ║');
  console.log('╠══════════════════════════════════════════════╣');
  for (let i = 1; i <= TATAMIS_ACTIVOS; i++) crearTatami(i, PUERTO_BASE + i - 1);

  setTimeout(() => {
    const ip  = getLocalIP();
    const pad = s => s.padEnd(30);
    console.log('╠══════════════════════════════════════════════╣');
    console.log(`║  IP de la laptop: ${ip.padEnd(27)}║`);
    console.log('╠══════════════════════════════════════════════╣');
    console.log('║  URLs para móviles / réferis:                ║');
    for (let i = 1; i <= TATAMIS_ACTIVOS; i++)
      console.log(`║   Tatami ${i}  http://${pad(ip+':'+(PUERTO_BASE+i-1))}║`);
    console.log('╠══════════════════════════════════════════════╣');
    console.log('║  URLs HDMI (esta laptop):                    ║');
    for (let i = 1; i <= TATAMIS_ACTIVOS; i++)
      console.log(`║   Tatami ${i}  http://${pad('localhost:'+(PUERTO_BASE+i-1))}║`);
    console.log('╠══════════════════════════════════════════════╣');
    console.log('║  Arquitectura v3: eventos delta + ACK        ║');
    console.log('║  Ctrl+C para detener                         ║');
    console.log('╚══════════════════════════════════════════════╝\n');
  }, 600);
}

iniciar();
